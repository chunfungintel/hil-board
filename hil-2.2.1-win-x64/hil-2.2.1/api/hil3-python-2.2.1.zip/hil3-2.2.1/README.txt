Welcome to the HIL (H-Cloud Hardware IO Lite) python module.
http://harts.intel.com/hil


Prerequisites:
-------------
    - Python version 2.7
    - PySerial version 2.7
    - Tested on Windows 7, 8.1 (x64) and MacOS (version?), Ubuntu (16.04)


    !!IMPORTANT!!

    Before running, you will need to install the Arduino drivers and flash the firmware using the bundle from
    https://soco.intel.com/docs/DOC-975140
        *** For this beta release, the firmware is not yet published on Intel Blue.
        Please use the bundle HARTS_IO_Lite_v5_bundle.zip provided in this release.

	The same firmware is valid for single Hil or stacked HILs configurations.

	Stacked HILs configuration
	    - the first Hil board on the stack is referred as 'hil1' (the closest to the Arduino board),
	        whereas the last one is referred as 'hilN'


Installation:
------------
To install, unpack the zip file and run:

    1)  Unpack the HARTS_IO_Lite_v5_bundle.zip and run the file hil_upload_fw.bat to install the Arduino USB drivers and flash the HIL firmware
    2)  python ./setup.py install


Questions:
---------
    harts_support@intel.com


Examples:
------------------------
    See the file api.txt for the API documentation and example usage


Revision History:
------------------------
1.0.0   10/01/2014  AM  - Initial release.
1.1.0   10/21/2014  AM  - Added support to query the state of the SIM switch and set state for HIL board and SIM switch
                          via HilStack object.
1.1.2   11/20/2014  AM  - SIM switch resources index start from 0, e.g. simsw0, simsw1, SIM0-SIM7.
1.1.3   12/10/2014  AM  - SIM Switch: provided new methods in the class SimSwitchBoards: disable(), enable(), select_sim().
1.2.0   12/12/2014  AM  - Using Arduino f/w version 5.2.0 with commands terminated by '\r' and commands echoed.
                        - The class 'HilBoards' is renamed to 'HilBoardCtrl', the class 'SimSwitches' is renamed to 'SimSwitchCtrl'
                        - HilStack.get_hil_boards() and HilStack.get_sim_switches() are renamed to
                          HilStack.get_hil_ctrl() and HilStack.get_simsw_ctrl().
                        - Changed COM speed from 57600 to 9600 for better stability.
1.2.1   01/20/2015  AM  - Decreased timeout for Arduino executing commands at 60 seconds. Fixed bug for infinite loop when timed out.
1.2.2   01/23/2015  AM  - SIM switch: provided support to read the presence of the SIM cards inside the slots of the SIM switch.
                        - [FW 5.2.1] HIL board(s) can be stacked together with the SIM switch(es) only with the power board.
                        - The connection to Arduino is thread-safe.
1.0.2   03/31/2015	AM  - Renamed version from 1.2.3 to 1.0.2 to be in sync with the hil_suite version
						  This revision history is obsolete. Follow README.TXT from hil_suite.
2.2.0  07/24/2017   AM  - [Feature] SMS18408536 | Watchdog support (HIL to power off modem if connection with congatec is lost)
        On the client side, there is no notification mechanism in case the Arduino got reset. 
        The watchdog should reset the Arduino only in case the host PC freezes, so the campaign is compromised anyway.
