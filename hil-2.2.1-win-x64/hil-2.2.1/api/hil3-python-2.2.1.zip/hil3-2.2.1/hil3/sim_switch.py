############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

__author__ = 'amihaila'

import json
import re
import logging
from arduinoctrl import ArduinoMega
from hilexceptions import *
from ast import literal_eval


class SimSwitchCtrl():
    """
    Controller for SIM Switch boards
    """

    CMD_TYPE_SIMSW       = 'S'
    CMD_SET              = 's'
    CMD_GET              = 'g'
    CMD_LIST_CONFIG      = 'c'
    PARAM_BOARD          = 'b'
    CMD_SIM_SET_STATE    = 'r'
    CMD_SIM_SELECT       = 's'
    CMD_SIM_ENABLE       = 'e'
    CMD_SIM_DISABLE      = 'd'

    def __init__(self, arduino):
        self.__arduino = arduino
        self.__boards = None
        self.__sims = None

    def __del__(self):
        # if self.__arduino.is_serial_open():
        #    self.set_state(0, 0)
        pass

    def __repr__(self):
        return '("TODO")'

    def setup(self):
        try:
            res = self.__arduino.query_resources(SimSwitchCtrl.CMD_TYPE_SIMSW)
            self.__boards = res['SIMSW']['boards']
            self.__sims = res['SIMSW']['sims']
        except Exception as ex:
            raise Exception("Error on querying the SIM switches for the available resources!\r\nException = %s" % str(ex))

    def __get_board_id(self, board):
        board = board.lower()

        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        if board not in self.__boards:
            raise HilBoardInvalidResourceException("Unknown or invalid resource specified (%s). Valid values are: "
                                                       "%s" % (board, repr(self.get_boards())))

        return self.__boards[board]

    def __get_sim_id(self, sim):
        sim = sim.upper()

        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        if sim not in self.__sims:
            raise HilBoardInvalidResourceException("Unknown or invalid resource specified (%s). Valid values are: "
                                                       "%s" % (sim, repr(self.get_sims())))

        return self.__sims[sim]

    def get_settings(self):
        connected = self.__arduino.is_serial_open()

        return {'resources': self.get_sims() if connected else None}

    def select_sim(self, sim, board='simsw0'):
        """
        Selects exclusively a SIM card on a SIM switch board. i.e. only one SIM card is selected
        :param sim: the SIM card to select. See get_sims() for possible values.
        :param board: the SIM switch board, see get_boards() for possible values.
        :return:
        """
        logging.info('select_sim(%s, %s)', sim, board)

        [board_id, sim_id] = [self.__get_board_id(board), self.__get_sim_id(sim)]
        self.__arduino.exec_command(SimSwitchCtrl.CMD_TYPE_SIMSW + SimSwitchCtrl.CMD_SET +
                            SimSwitchCtrl.PARAM_BOARD + str(board_id) + SimSwitchCtrl.CMD_SIM_SELECT + str(sim_id))


    def disable(self, board='simsw0'):
        """
        Disables the selected SIM, i.e. no SIM is reported to DUT although one was selected via self.select_sim() or self.set_state()
        :param board: the SIM switch board, see get_boards() for possible values.
        :return:
        """
        logging.info('disable(%s)', board)

        board_id = self.__get_board_id(board)
        self.__arduino.exec_command(SimSwitchCtrl.CMD_TYPE_SIMSW + SimSwitchCtrl.CMD_SET +
                            SimSwitchCtrl.PARAM_BOARD + str(board_id) + SimSwitchCtrl.CMD_SIM_DISABLE)

    def enable(self, board='simsw0'):
        """
        Enables the selected SIM, i.e. the SIM is reported to DUT if the SIM is present in the slot selected via self.select_sim() or self.set_state()
        :param board: the SIM switch board, see get_boards() for possible values.
        :return:
        """
        logging.info('enable(%s)', board)

        board_id = self.__get_board_id(board)
        self.__arduino.exec_command(SimSwitchCtrl.CMD_TYPE_SIMSW + SimSwitchCtrl.CMD_SET +
                            SimSwitchCtrl.PARAM_BOARD + str(board_id) + SimSwitchCtrl.CMD_SIM_ENABLE)

    def set_state(self, sim, enabled, board='simsw0'):
        """
        Sets the state of a SIM switch
        :param sim: the SIM card to select. See get_sims() for possible values.
        :param enabled: ['H', 'h', '1', 1, 'High', 'HIGH', 'on', 'ON'] if the selected SIM is to be enabled,
            ['L', 'l', '0', 0, 'Low', 'LOW', 'off', 'OFF'] otherwise, or ArduinoMega.HIGH and ArduinoMega.LOW.
        :param board: the SIM switch board, see get_boards() for possible values.
        :return:
        """
        logging.info('set_state(%s, %s, %s)', sim, str(enabled), board)

        enabled = ArduinoMega.convert_val(enabled)
        [board_id, sim_id] = [self.__get_board_id(board), self.__get_sim_id(sim)]

        self.__arduino.exec_command(SimSwitchCtrl.CMD_TYPE_SIMSW + SimSwitchCtrl.CMD_SET +
                            SimSwitchCtrl.PARAM_BOARD + str(board_id) +
                            SimSwitchCtrl.CMD_SIM_SET_STATE + str(sim_id) + '=' + str(enabled))

    def get_state(self, board='simsw0'):
        """
        Gets the state of a SIM switch
        :param board: the SIM switch. See get_boards() for possible values.
        :return: The selected SIM and its state as {'sim': <active_sim>, 'enabled': True|False}
        """
        logging.info('get_state(%s)', board)

        board_id = self.__get_board_id(board)
        result = self.__arduino.exec_command(SimSwitchCtrl.CMD_TYPE_SIMSW + SimSwitchCtrl.CMD_GET +
                            SimSwitchCtrl.PARAM_BOARD + str(board_id))
        state_res = {}
        if result:
            [sim, oe] = result.split('=')
            sim = 'SIM' + sim
            enabled = True if int(oe) == 1 else False
            state_res['sim'] = sim
            state_res['enabled'] = enabled

        return state_res

    def get_boards(self):
        """
        Gets the list of all SIM switches
        :return: The list of all sim switches
        """
        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        return sorted(self.__boards.keys()) if self.__boards else {}

    def get_sims(self):
        """
        Gets the list of all SIM slots available for any SIM switch
        :return: the list of all SIM slots available for any SIM switch
        """
        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        return sorted(self.__sims.keys()) if self.__sims else {}

    def get_sim_config(self, board='simsw0'):
        """
        Gets the SIM configuration for a SIM switch, i.e. the list of the detected SIMs inside the slots of a SIM switch
        :param board:  the SIM switch. See get_boards() for possible values.
        :return: a list with all the detected SIM cards
        """
        logging.info('get_sim_config(%s)', board)

        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        board_id = self.__get_board_id(board)
        result = self.__arduino.exec_command(SimSwitchCtrl.CMD_TYPE_SIMSW + SimSwitchCtrl.CMD_LIST_CONFIG +
                            SimSwitchCtrl.PARAM_BOARD + str(board_id))
        sims = []
        try:
            sims = ['SIM' + str(s) for s in literal_eval(result)]
        except Exception as ex:
            logging.error("Invalid response from Arduino: %s", ex.message)
            raise SimSwitchWrongCmdException("Invalid response from Arduino as it can't be converted to list: %s" % ex.message)

        return sims

    def get_all_states(self):
        """
        Gets the states of all SIM switches
        :return: A dictionary with the states of all SIM switches
        """
        logging.info('simsw::get_all_states()')

        states = {}
        for b in self.get_boards():
            states[b] = self.get_state(b)

        return states
