############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

import re

from arduinoctrl import ArduinoMega
from hilboard import HilBoardCtrl
from sim_switch import SimSwitchCtrl
from hilexceptions import *

__author__ = 'amihaila'


class HilStack():
    """
    Facade for accessing the HIL Boards and SIM Switches controllers
    """

    def __init__(self):
        """
        Prepares the Arduino controller and HIL and SIM Switch boards
        :return:
        """
        self.__arduino          = ArduinoMega()
        self.__hil              = HilBoardCtrl(self.__arduino)

        self.__sim_sw           = SimSwitchCtrl(self.__arduino)

    def __del__(self):
        """
        Disconnects the Arduino board if it was connected
        :return:
        """
        if self.is_connected():
            self.disconnect()

    def __repr__(self):
        return '("TODO")'

    def connect(self, device=None, session='', reset=True, watchdog=False):
        """
        Connects the host PC to HIL board(s) via Arduino

        :param: device: the COM port number
        :param: session: the session id in case watchdog is enabled
        :param: reset: reset Arduino (works only in Windows)
        :param: watchodg: true if watchdog must be enabled, false otherwise
        :return: None, raises exceptions, see hilexceptions.py
        """
        # TODO Setup HilBoard and SIM s/w only if they are detected
        try:
            self.__arduino.connect(session, device, reset, watchdog)
            self.__hil.setup()
            self.__sim_sw.setup()
        except HilAlreadyConnected as e:
            raise e
        except HilException as e:
            self.__arduino.disconnect()  # Close the port in case of errors when opening the connection
            raise e

    def disconnect(self):
        """
        Disconnects the host PC from HIL board(s)
        :return: None
        """
        self.__arduino.disconnect()

    def is_connected(self):
        """
        Checks if the board is connected
        :return: True if the Arduino is connected and False otherwise
        """
        return self.__arduino.is_serial_open()

    def ping(self):
        """
        Pings the Arduino board.
        :return: True if the board is online, False otherwise.
        :raises: UnresponsiveArduinoException if the serial communication is open but the Arduino is not responsive.
        """
        return self.__arduino.ping()

    def reset(self):
        """
        TODO Resets the Arduino board by setting the DTR line to HIGH and then LOW.
        See the reset circuit from Arduino.
        The reset will not work in case the USB->UART interface of Arduino is not responsive
        :return:
        """
        # TODO
        # self.__arduino.__serial.setDTR() ?
        pass

    def sleep(self, seconds):
        """
        Informs Arduino that host intends to sleep. Call wake() when host wakes up.
        Arduino will reset the WDT by itself while the host sleeps.
        If the host doesn't wake up in time, the Arduino's WDT will reset the board.
        :param seconds: the amount of seconds intends to sleep
        :return:
        """
        self.__arduino.sleep(seconds)

    def wake(self):
        """
        Informs Arduino that host woke up.
        :return:
        """
        self.__arduino.wake()

    def get_hil_ctrl(self):
        """
        Returns the HilBoardCtrl instance
        :return: the HilBoardCtrl instance
        """
        return self.__hil

    def get_simsw_ctrl(self):
        """
        Returns the SimSwitchCtrl instance
        :return: the SimSwitchCtrl instance
        """
        return self.__sim_sw

    def get_boards(self):
        """
        Returns the list of all boards detected in the stack
        """
        return {'online': self.ping(), 'hils': self.__hil.get_boards(), 'simsws': self.__sim_sw.get_boards()}

    def get_settings(self):
        """
        Gets the settings used for Arduino, HIL boards and SIM Switches
        :return: the settings used for Arduino, HIL boards and SIM Switches
        """
        res = {'arduino': self.__arduino.get_settings(),
               'hils': self.__hil.get_settings(),
               'simsws': self.__sim_sw.get_settings()}
        return res

    def set_state(self, board, resource, state):
        """
        Set the state of a resource on a board
        :param resource: the resource string
        :param state: the new state
        :param board: the board identifies
        :return:
        """
        # TODO There is no need to specify the board id in case the "stack" has only one board, e.g. HIL or SIM s/w.
        rex_hil = re.compile('(?i)hil[0-9]+').match(board)
        rex_simsw = re.compile('(?i)simsw[0-9]+').match(board)

        if not rex_hil and not rex_simsw:
            raise Exception("Invalid board identifier. Expected hil[0-9]+ or simsw[0-9]+")

        if rex_hil:
            self.__hil.set(resource, state, board)
        if rex_simsw:
            self.__sim_sw.set_state(resource, state, board)

    def get_state(self, board, resource=None):
        """
        Gets the state of a resource on a HIL board/SIM switch
        :param board: the board identifies
        :param resource: the resource string
        :return: the state for hilboard and [sim, state] for simswitch
        """
        # TODO There is no need to specify the board id in case the "stack" has only one board, e.g. HIL or SIM s/w.
        rex_hil = re.compile('(?i)hil[0-9]+').match(board)
        rex_simsw = re.compile('(?i)simsw([0-9]+)').match(board)

        if not rex_hil and not rex_simsw:
            raise Exception("Invalid board identifier. Expected hil[0-9]+ or simsw[0-9]+")

        if rex_hil:
            return self.__hil.get(resource, board)
        if rex_simsw:
            return self.__sim_sw.get_state(board)

