############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

import unittest

import io
import serial
import time
import datetime

from hil3 import hilstack


reference =   [         # board 0 (on top)
                        [["+COPS: 0,0,\"E-Plus\"", "+CCID: 894921003065772796"],
                        ["+COPS: 0,0,\"o2 - de\"", "+CCID: 8949226124842226371"],
                        ["+COPS: 0,0,\"Vodafone.de\"", "+CCID: 89492021126022978572"],
                        ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200000992039623"],
                        ["+COPS: 0,0,\"o2 - de\"", "+CCID: 8949228140542169412"] ,
                        ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038797281"],
                        ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200000690579748"],
                        ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038798305"]],

                         # board 1 (below)
                         [
                         ["N/A", "N/A"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038797273"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038797299"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038797265"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038798263"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038798271"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038798289"],
                         ["+COPS: 0,0,\"Telekom.de\"", "+CCID: 89490200001038798297"]]]


reference_stress = [
        ['o2 - de',     '8949228140542169412'],
        ['Telekom.de',  '89490200001038798297'],
        ['E-Plus',      '8949226124842226371'],
        ['Vodafone.de', '89492021126022978572'],
        ['Telekom.de',  '89490200001038797265'],
        ['Telekom.de',  '89490200001038797281'],
        ['Telekom.de',  '89490200001038797273'],
        ['Telekom.de',  '89490200001038798305']]

########################################################################################################################
#
# Core tests for setup and teardown of all test campaigns
#
########################################################################################################################

MODEM_COM_PORT='COM11'

class Modem():
    def __init__(self, port=MODEM_COM_PORT):
        self.__port = port
        self.__serial = None

    def __del__(self):
        if self.__serial and self.__serial.isOpen():
            self.__serial.close()
        self.__serial = None

    def connect(self):
        self.__serial = serial.Serial(port=self.__port, baudrate=115200, timeout=4)  # 0

    def disconnect(self):
        self.__serial.close()

    def send_cmd(self, cmd, sleep_before=0.3, sleep_after = 1):
        if not self.__serial.isOpen():
            raise Exception("The modem is not connected!")

        result = None

        try:
            self.__serial.flushInput()
            cmd = cmd + '\r'
            bytes_sent = self.__serial.write(cmd)

            if bytes_sent != len(cmd):
                raise Exception("Error on sending the command %s to modem" % cmd)

            time.sleep(sleep_before)
            if self.__serial.inWaiting():
                # sio = io.TextIOWrapper(io.BufferedRWPair(self.__serial, self.__serial), newline='\r')
                result = self.__serial.readlines()
        except serial.SerialException:
            raise Exception("Error on sending the command %s to modem on port %s!" % (cmd, self.__serial.name))

        # print result
        time.sleep(sleep_after)

        return result


class ModemPbReady():
    def __init__(self, port=MODEM_COM_PORT):
        self.__port = port
        self.__serial = None

    def __del__(self):
        if self.__serial and self.__serial.isOpen():
            self.__serial.close()
        self.__serial = None

    def connect(self):
        self.__serial = serial.Serial(port=self.__port, baudrate=115200, timeout=0.2)  # 0

    def disconnect(self):
        self.__serial.close()

    def send_cmd(self, cmd):
        self.__serial.flushInput()
        done = False
        # print cmd
        self.__serial.write(cmd + '\r')
        # time.sleep(0.1)
        result = []  # command result
        loop_count = 600 # 30 s max timeout

        while not done and loop_count:
            if self.__serial.inWaiting():
                lines = self.__serial.readlines()
                result += lines
                for line in lines:
                    if line.find('OK') != -1:
                        done = True
                        break
                    elif line.find('ERROR') != -1:
                        done = True
                        break
                if done:
                    break
            time.sleep(0.05)
            loop_count -= 1

        if not loop_count:
            result += 'TIMEOUT!!!'
            
        # print result
        return result

    def measure_pb_ready(self):
        self.__serial.write('AT+CFUN=4\r')
        time.sleep(3)
        self.__serial.flushInput()

        self.__serial.write('AT+CFUN=1\r')
        time.sleep(0.1)
        done = False
        result = ''
        # start = datetime.datetime.now()
        start = time.clock()
        while not done:
            if self.__serial.inWaiting():
                # result = self.__serial.read(1)
                # c = self.__serial.read(1)
                lines = self.__serial.readlines()
                if '+PBREADY\r\n' in lines:
                    done = True
                #if c in ['\r', '\n']:
                #    result = ''
                # result = result + c
                # if result.find('+PBREADY') != -1:
        # end = datetime.datetime.now()
        end = time.clock()

        self.__serial.write('AT+CFUN=4\r')
        time.sleep(3)
        self.__serial.flushInput()

        self.__serial.write('AT+CFUN=35\r')                        #  Power-Off/Power-On Single (U)SIM card
        time.sleep(2)
        self.__serial.flushInput()

        delta = end - start
        # return delta.seconds
        return delta

    def measure_sim_ready_all(self, iter, sim_sw):
        for s in range(0, 8):
            sim_sw.set_state(s, 1, 0)
            time.sleep(0.5)
            print 'iter=' + str(iter) + ' sim=' + str(s) + ' ' + str(self.measure_sim_ready())


    def measure_sim_ready(self):
        self.__serial.write('AT+CFUN=4\r')
        time.sleep(3)
        self.__serial.flushInput()

        self.__serial.write('AT+CFUN=1\r')
        time.sleep(1)
        self.__serial.flushInput()
        done = False
        result = ''
        start = time.clock()
        while not done:
            self.__serial.write('AT+XSIMSTATE?\r')
            time.sleep(0.25)
            if self.__serial.inWaiting():
                # result = self.__serial.read(1)
                # c = self.__serial.read(1)
                lines = self.__serial.readlines()
                if '+XSIMSTATE: 0,7,1,1\r\n' in lines:
                    done = True
        end = time.clock()

        self.__serial.write('AT+CFUN=4\r')
        time.sleep(3)
        self.__serial.flushInput()

        self.__serial.write('AT+CFUN=35\r')                        #  Power-Off/Power-On Single (U)SIM card
        time.sleep(2)
        self.__serial.flushInput()

        delta = end - start
        return delta

    def attach(self):
        self.send_cmd('AT+CFUN=4')   # airplane = ON
        time.sleep(3)

        self.send_cmd('AT+CFUN=1')  # airplane = OFF
        time.sleep(3)

        self.send_cmd('AT+XACT=1')  # prefer UMTS (3G)
        time.sleep(1)

        # wait for the SIM to be ready
        done = False
        while not done:
            self.__serial.write('AT+XSIMSTATE?\r')
            # time.sleep(0.25)
            if self.__serial.inWaiting():
                lines = self.__serial.readlines()
                for line in lines:
                    if line.find('+XSIMSTATE: 0,7,1,1') != -1:
                        done = True
                        break
        print 'SIM ready'
        self.send_cmd('AT+COPS=0')  # attach
        time.sleep(3)
        result = self.send_cmd('AT+COPS?')  # query for operator
        operator = result[1][:-2]
        operator = operator[operator.find('"')+1:operator.rfind('"')]
        result = self.send_cmd('AT+CCID?')
        sim_id = result[1][:-2].split(' ')[1]
        print self.send_cmd('AT@uicc:get_cardprofile_primary()')

        self.send_cmd('AT+COPS=2')  # detach
        time.sleep(3)

        self.send_cmd('AT+CFUN=4')      # airplane mode
        time.sleep(3)

        return [operator, sim_id]

    def sim_ready(self):
        self.send_cmd('AT+CFUN=4')   # airplane = ON
        time.sleep(3)

        self.send_cmd('AT+CFUN=1')  # airplane = OFF
        time.sleep(3)

        self.send_cmd('AT+XACT=1')  # prefer UMTS (3G)
        time.sleep(1)

        # wait for the SIM to be ready
        done = False
        while not done:
            self.__serial.write('AT+XSIMSTATE?\r')
            # time.sleep(0.25)
            if self.__serial.inWaiting():
                lines = self.__serial.readlines()
                for line in lines:
                    if line.find('+XSIMSTATE: 0,7,1,1') != -1:
                        done = True
                        break
        print 'SIM ready'

    def sim_not_ready(self):
        self.send_cmd('AT+CFUN=4')      # airplane mode
        time.sleep(3)

    def phonebook_write_entry(self, index, phone, name):
        """
        Tests by writing a phone book entry
        """        
        #AT+CPBW=20,"+4915174402148",145,"TEST_HARTS_20"
        result = self.send_cmd('AT+CPBW=%d,"%s",145,"%s"' % (index, phone, name))
        time.sleep(1)
        return result

    def phonebook_read_entry(self, index):
        """
        Tests by reading a phone book entry
        """
        result = self.send_cmd('AT+CPBR=%d' % (index))
        time.sleep(1)        
        return result

    def phonebook_delete_entry(self, index):
        """
        Tests by reading a phone book entry
        """
        result = self.send_cmd('AT+CPBW=%d' % (index))
        time.sleep(1)        
        return result    


class BasicSimSwitchTest(unittest.TestCase):
    def setUp(self):
        global stack, sim_sw, hil, modem

        modem = Modem()

        stack = hilstack.HilStack()
        stack.connect()

        sim_sw = stack.get_simsw_ctrl()
        hil = stack.get_hil_ctrl()
        hil.reset()

    def tearDown(self):
        global stack, sim_sw, hil, modem

        modem = None
        hil.reset()
        hil = None
        sim_sw = None
        stack.disconnect()
        stack = None


class PerformanceTest(unittest.TestCase):
    @unittest.skip("Disabled on purpose")
    def test_0_measure_sim_ready(self):
        stack = hilstack.HilStack()
        stack.connect()

        sim_sw = stack.get_simsw_ctrl()
        hil = stack.get_hil_ctrl()
        hil.reset()

        hil.set('POWER1', 'on')
        time.sleep(12)
        hil.set('USB1', 'on')
        time.sleep(5)

        modem = ModemPbReady()
        modem.connect()

        for i in range(0, 15):
            print modem.measure_sim_ready_all(i, sim_sw)

        modem.disconnect()

        hil.set('USB1', 'off')
        time.sleep(5)
        hil.set('POWER1', 'off')
        time.sleep(5)

        stack.disconnect()
        hil = None
        sim_sw = None
        stack = None

    @unittest.skip("Disabled on purpose")
    def test_1_attach(self):
        stack = hilstack.HilStack()
        stack.connect()

        sim_sw = stack.get_simsw_ctrl()
        hil = stack.get_hil_ctrl()
        hil.reset()

        hil.set('POWER1', 'on')
        time.sleep(12)
        hil.set('USB1', 'on')
        time.sleep(5)

        modem = ModemPbReady()
        modem.connect()

        for s in range(0, 8):
            sim_sw.select_sim(s)
            time.sleep(0.5)
            [operator, ccid] = modem.attach()
            print 'SIM=' + str(s) + ' operator=' + operator + ', CCID=' + ccid
            self.assertEqual(operator, reference_stress[s][0])
            self.assertEqual(ccid, reference_stress[s][1])

        modem.disconnect()

        hil.set('USB1', 'off')
        time.sleep(5)
        hil.set('POWER1', 'off')
        time.sleep(5)

        stack.disconnect()
        hil = None
        sim_sw = None
        stack = None

    # @unittest.skip("Disabled on purpose")
    def test_2_attach_stress(self):
        stack = hilstack.HilStack()
        stack.connect()

        sim_sw = stack.get_simsw_ctrl()
        hil = stack.get_hil_ctrl()
        hil.reset()

        hil.set('POWER1', 'on')
        time.sleep(12)
        hil.set('USB1', 'on')
        time.sleep(5)
        modem = ModemPbReady()
        modem.connect()
        
        for i in range(0, 100000):
            print 'Iteration ' + str(i) + ' started at: ' + str(time.localtime())

            for s in range(0, 8):
                sim_sw.select_sim('SIM' + str(s))
                time.sleep(0.5)
                [operator, ccid] = modem.attach()
                print 'SIM=' + str(s) + ' operator=' + operator + ', CCID=' + ccid
                self.assertEqual(operator, reference_stress[s][0])
                self.assertEqual(ccid, reference_stress[s][1])

        time.sleep(3)
        modem.disconnect()
        hil.set('USB1', 'off')
        time.sleep(5)
        hil.set('POWER1', 'off')
        time.sleep(5)

        stack.disconnect()
        hil = None
        sim_sw = None
        stack = None

    @unittest.skip("Disabled on purpose")
    def test_2_phonebook_access(self):
        stack = hilstack.HilStack()
        stack.connect()

        sim_sw = stack.get_simsw_ctrl()
        hil = stack.get_hil_ctrl()
        hil.reset()

        hil.set('POWER1', 'on')
        time.sleep(12)
        hil.set('USB1', 'on')
        time.sleep(5)
        modem = ModemPbReady()
        modem.connect()

        sim_sw.select_sim(7) # select T-Mobile
        time.sleep(0.5)

        modem.sim_ready()

        print 'Appending into phonebook...'
        start = time.clock()
        for eidx in range(1,251):
            # print 'write ' + str(eidx)
            modem.phonebook_write_entry(eidx, '+4900000000' + str(eidx), 'TEST_HARTS_' + str(eidx))
        end = time.clock()
        print 'Appending into phonebook is done.'
        print 'Average append time = ' + str((end - start) / 250)

        print 'Reading phonebook ...'
        start = time.clock()
        for eidx in range(1,251):
            # print 'read ' + str(eidx)
            modem.phonebook_read_entry(eidx)
        end = time.clock()
        print 'Reading phonebook is done.'
        print 'Average read time = ' + str((end - start) / 250)

        print 'Erase all phonebook ...'
        for e in range(1, 251):
            modem.phonebook_delete_entry(e)
        print 'Erase all phonebook is done.'

        modem.sim_not_ready()
        modem.disconnect()
        hil.set('USB1', 'off')
        time.sleep(5)
        hil.set('POWER1', 'off')
        time.sleep(5)

        stack.disconnect()
        hil = None
        sim_sw = None
        stack = None


class TraceTest(unittest.TestCase):    
    @unittest.skip("Disabled on purpose")
    def test_0(self):
        stack = hilstack.HilStack()
        stack.connect()

        hil = stack.get_hil_ctrl()
        hil.reset()

        hil.set('POWER1', 'on')
        time.sleep(12)
        hil.set('USB1', 'on')
        time.sleep(5)

        modem = ModemPbReady()
        modem.connect()

        modem.send_cmd('at+xsystrace=0,"bb_sw=1","bb_sw=sdl:th,tr,st,mo,db,pr,lt,"')
        time.sleep(3)

        modem.send_cmd('at+trace=1')
        print 'Please start collecting trace in STT!'
        time.sleep(15)

        sims = ['SIM' + `s` for s in range(1, 9)]
        for iter in range(0,10):
            print 'Iteration ' + str(iter) + ' started!'
            for s in sims:
                stack.set_state('simsw1', s, 'on')
                time.sleep(2)

                modem.attach()
                time.sleep(3)
        
        modem.send_cmd('at+trace=0')
        print 'Please stop collecting trace in STT!'
        time.sleep(15)
       
        modem.disconnect()

        hil.set('USB1', 'off')
        time.sleep(5)
        hil.set('POWER1', 'off')
        time.sleep(5)

        stack.disconnect()
        hil = None
        sim_sw = None
        stack = None
       
########################################################################################################################
#
# Tests specific to the python API
#
########################################################################################################################
class TestSimSwitchPythonAPIWithDut(BasicSimSwitchTest):

    @unittest.skip("It takes too long time with the power cycle")
    def test_0_power_cycle(self):
        global sim_sw, hil
        global modem

        for sim in range(1, 8):
            # print 'Testing SIM #%d ...' % sim
            sim_sw.set_state(sim, 1, 1)
            time.sleep(1)

            # print 'POWER on'
            hil.set('POWER1', 'on')
            time.sleep(11)

            # print 'USB on'
            hil.set('USB1', 'on')
            time.sleep(10)

            # print 'Connect to modem'
            modem.connect()
            time.sleep(3)

            # print 'AT+CMEE=2 - more descriptive error code'
            res = modem.send_cmd('AT+CMEE=2')   # get more descriptive error code
            #print res

            time.sleep(2)
            # print 'Attach to network'
            res = modem.send_cmd('AT+COPS=0')   # register to network
            # print res

            time.sleep(5)
            # print 'Query network'
            network = modem.send_cmd('AT+COPS?')    # query for the network
            operator = network[1][:-2]

            time.sleep(2)
            # print 'Get ID'
            sim_id_res = modem.send_cmd('AT+CCID?')
            sim_id = sim_id_res[1][:-2]
            print "SIM %d, operator=%s, id=%s" % (sim, operator, sim_id)

            time.sleep(5)
            # print 'Detach'
            res = modem.send_cmd('AT+COPS=2')         # unregister from network
            # print res

            time.sleep(5)
            # print 'Disconnect modem'
            modem.disconnect()
            time.sleep(2)

            hil.set('USB1', 'off')
            time.sleep(1)

            hil.set('POWER1', 'off')
            time.sleep(1)

        self.assertTrue(True)

    @unittest.skip("This tests only the SIM switch 0")
    def test_1_airplane_simsw_0_only(self):
        global sim_sw, hil
        global modem

        # print 'POWER on'
        hil.set('POWER1', 'on')
        time.sleep(11)

        # print 'USB on'
        hil.set('USB1', 'on')
        time.sleep(10)

        # print 'Connect to modem'
        modem.connect()
        time.sleep(3)

        # print 'AT+CMEE=2 - more descriptive error code'
        res = modem.send_cmd('AT+CMEE=2')   # get more descriptive error code
        #print res

        # put in airplane mode
        modem.send_cmd('AT+CFUN=4')
        time.sleep(2)

        for sim in range(1, 8):
            # print 'Testing SIM #%d ...' % sim
            sim_sw.set_state(sim, 1, 1)
            time.sleep(1)

            # put modem in full functionality
            modem.send_cmd('AT+CFUN=1')
            time.sleep(2)

            # print 'Attach to network'
            res = modem.send_cmd('AT+COPS=0')   # register to network
            # print res

            time.sleep(5)
            # print 'Query network'
            network = modem.send_cmd('AT+COPS?')    # query for the network
            operator = network[1][:-2]

            time.sleep(2)
            # print 'Get ID'
            sim_id_res = modem.send_cmd('AT+CCID?')
            sim_id = sim_id_res[1][:-2]
            print "SIM %d, operator=%s, id=%s" % (sim, operator, sim_id)

            time.sleep(5)
            # print 'Detach'
            res = modem.send_cmd('AT+COPS=2')         # unregister from network
            # print res

            # put in airplane mode
            modem.send_cmd('AT+CFUN=4')
            time.sleep(5)

        time.sleep(5)
        # print 'Disconnect modem'
        modem.disconnect()
        time.sleep(2)

        hil.set('USB1', 'off')
        time.sleep(1)

        hil.set('POWER1', 'off')
        time.sleep(1)

        self.assertTrue(True)

    @unittest.skip("This tests only the SIM switch 0")
    def test_2_airplane_simsw_cascaded_mux_0(self):
        global sim_sw, hil, modem

        # print 'POWER on'
        hil.set('POWER1', 'on')
        time.sleep(11)

        # print 'USB on'
        hil.set('USB1', 'on')
        time.sleep(10)

        # print 'Connect to modem'
        modem.connect()
        time.sleep(3)

        # print 'AT+CMEE=2 - more descriptive error code'
        res = modem.send_cmd('AT+CMEE=2')   # get more descriptive error code
        #print res

        # put in airplane mode
        modem.send_cmd('AT+CFUN=4')
        time.sleep(2)

        sim_sw.set_state(0, 1, board=1) # mux 1 port 0 comes from mux 0 output
        time.sleep(1)

        for sim in range(0, 8):
            # print 'Testing SIM #%d ...' % sim
            sim_sw.set_state(sim, 1, board=0)
            time.sleep(3)

            # put modem in full functionality
            modem.send_cmd('AT+CFUN=1')
            time.sleep(2)

            # print 'Attach to network'
            res = modem.send_cmd('AT+COPS=0')   # register to network
            # print res

            time.sleep(5)
            # print 'Query network'
            network = modem.send_cmd('AT+COPS?')    # query for the network
            operator = network[1][:-2]

            time.sleep(2)
            # print 'Get ID'
            sim_id_res = modem.send_cmd('AT+CCID?')
            sim_id = sim_id_res[1][:-2]
            print "SIM %d, operator=%s, id=%s" % (sim, operator, sim_id)

            time.sleep(5)
            # print 'Detach'
            res = modem.send_cmd('AT+COPS=2')         # unregister from network
            # print res

            # put in airplane mode
            modem.send_cmd('AT+CFUN=4')
            time.sleep(5)

        time.sleep(5)
        # print 'Disconnect modem'
        modem.disconnect()
        time.sleep(2)

        hil.set('USB1', 'off')
        time.sleep(1)

        hil.set('POWER1', 'off')
        time.sleep(1)

        self.assertTrue(True)

    @unittest.skip("This testcase is disabled on purpose")
    def test_3_power_cycle_cascaded_mux_0_1(self):
        global sim_sw, hil, modem

        for board in [1, 0]:
            if board == 1:
                start_from = 1
            elif board == 0:
                sim_sw.set_state(0, 1, board=1)      # mux 1 port 0 comes from mux 0 output
                time.sleep(3)
                start_from = 0

            for sim in range(start_from, 8):
                sim_sw.set_state(sim, 1, board)
                time.sleep(3)

                hil.set('POWER1', 'on')
                time.sleep(11)
                hil.set('USB1', 'on')
                time.sleep(10)
                modem.connect()
                time.sleep(3)

                modem.send_cmd('AT+CFUN=1', sleep_after=10)                          # put modem in full functionality

                modem.send_cmd('AT+CMEE=2', sleep_after=5)                   # get more descriptive error code
                modem.send_cmd('AT+COPS=0', sleep_after=10)                  # register to network
                network = modem.send_cmd('AT+COPS?', sleep_after=10)        # query for the network
                operator = network[1][:-2]
                self.assertEqual(operator, reference[board][sim][0])

                sim_id_res = modem.send_cmd('AT+CCID?')                      # query for Integrated Circuit Card ID of the SIM Card
                sim_id = sim_id_res[1][:-2]
                self.assertEqual(sim_id, reference[board][sim][1])
                print "Switch %d SIM %d, %s, %s" % (board, sim, operator, sim_id)

                modem.send_cmd('AT+COPS=2', sleep_after=10)                                  # unregister from network

                modem.disconnect()
                time.sleep(2)
                hil.set('USB1', 'off')
                time.sleep(1)
                hil.set('POWER1', 'off')
                time.sleep(1)

    @unittest.skip("This testcase is disabled on purpose")
    def test_4_airplane_cascaded_mux_0_1(self):
        global sim_sw, hil, modem

        hil.set('POWER1', 'on')
        time.sleep(11)
        hil.set('USB1', 'on')
        time.sleep(10)
        modem.connect()
        time.sleep(3)

        modem.send_cmd('AT+CMEE=2')                 # get more descriptive error code
        modem.send_cmd('AT+CFUN=4')               # put in airplane mode

        for board in [0, 1]:
            if board == 1:
                start_from = 1
            elif board == 0:
                sim_sw.set_state(sim=0, state=1, board=1)   # mux 1 port 0 comes from mux 0 output
                time.sleep(3)
                start_from = 0

            for sim in range(start_from, 8):
                sim_sw.set_state(sim, 1, board)
                time.sleep(3)

                res = modem.send_cmd('AT+CFUN=35')                        #  Power-Off/Power-On Single (U)SIM card
                self.assertEqual(res[1][:-2], "OK")

                res = modem.send_cmd('AT+CFUN=1', sleep_after=2)
                self.assertEqual(res[1][:-2], "OK")

                # wait for PBREADY
                pb_ready = False
                start = time.clock()
                while not pb_ready:
                    res = modem.send_cmd('AT+XSIMSTATE?')
                    # self.assertEqual(res[5][:-2], "OK")
                    pb_ready = res[1][:-2] == '+XSIMSTATE: 0,7,1,1'
                    if not pb_ready:
                        # print "Wait for +PBREADY"
                        time.sleep(1)
                delta = time.clock() - start
                print delta

                res = modem.send_cmd('AT+COPS=0', sleep_after=2)                         # register to network
                self.assertTrue("OK" == res[1][:-2] or "OK" == res[2][:-2])
                network = modem.send_cmd('AT+COPS?', sleep_after=1)                # query for the network
                operator = network[1][:-4]
                self.assertEqual(operator, reference[board][sim][0])

                sim_id_res = modem.send_cmd('AT+CCID?')            # query for Integrated Circuit Card ID of the SIM Card
                sim_id = sim_id_res[1][:-2]
                self.assertEqual(sim_id, reference[board][sim][1])
                # print "Switch %d SIM %d, %s, %s" % (board, sim, operator, sim_id)

                res = modem.send_cmd('AT+COPS=2',sleep_after=1)                  # unregister from network
                self.assertTrue("OK" == res[1][:-2] or "OK" == res[2][:-2])
                res = modem.send_cmd('AT+CFUN=4')                        # put in airplane mode
                self.assertTrue("OK" == res[1][:-2] or "OK" == res[2][:-2])

        modem.disconnect()
        time.sleep(2)
        hil.set('USB1', 'off')
        time.sleep(1)
        hil.set('POWER1', 'off')
        time.sleep(1)

if __name__ == '__main__':
    unittest.main()


