############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

import unittest
import time

import arduinoctrl, hilstack, hilboard
from hilexceptions import *

all_resources_low_py_format_1_hil = {
                                      'USB2': 0, 'USB3': 0, 'USB1': 0,
                                      'USB_HS2': 0, 'USB_HS3': 0, 'USB_HS1': 0,
                                      'SWITCH3': 0, 'SWITCH2': 0, 'SWITCH1': 0,
                                      'POWER3': 0, 'POWER2': 0, 'POWER1': 0}

all_resources_high_py_format_1_hil = {
                                      'USB2': 1, 'USB3': 1, 'USB1': 1,
                                      'USB_HS2': 0, 'USB_HS3': 0, 'USB_HS1': 0,
                                      'SWITCH3': 1, 'SWITCH2': 1, 'SWITCH1': 1,
                                      'POWER3': 1, 'POWER2': 1, 'POWER1': 1}

EXPECTED_FW_VERSION = "2.0.0"

def _json_decode_dict(data):
    rv = {}
    for key, value in data.iteritems():
        if isinstance(key, unicode):
            key = key.encode('utf-8')
        if isinstance(value, unicode):
            value = value.encode('utf-8')
        elif isinstance(value, list):
            value = _json_decode_dict(value)
        elif isinstance(value, dict):
            value = _json_decode_dict(value)
        rv[key] = value
    return rv

########################################################################################################################
#
# Core tests for setup and teardown of all test campaigns
#
########################################################################################################################

class BasicHilNotConnectedTest(unittest.TestCase):
    def setUp(self):
        global stack, hil
        stack = hilstack.HilStack()
        hil = stack.get_hil_ctrl()

    def tearDown(self):
        global stack, hil
        stack = None
        hil = None


########################################################################################################################
#
# Tests specific to the Arduino python API
#
########################################################################################################################

class TestHilPythonAPINotConnected(BasicHilNotConnectedTest):
    def test_a_object_repr_ok(self):
        self.assertTrue(repr(hil), "(\"HIL Board is not connected yet and it can't be identified yet\")")

    def test_b_not_connected(self):
        self.assertFalse(stack.is_connected())

    def test_c_no_ping(self):
        self.assertFalse(stack.ping())

    def test_d_get_boards(self):
        try:
            hil.get_boards()
        except Exception:
            ex_thrown = True

        self.assertTrue(ex_thrown)

    def test_e_get_resources(self):
        try:
            hil.get_resources()
        except Exception:
            ex_thrown = True

        self.assertTrue(ex_thrown)

    def test_f_set_resource(self):
        ex_thrown = False

        try:
            hil.set('all', 1) # this must throw exception as the board is not connected yet!
        except:
            ex_thrown = True

        self.assertTrue(ex_thrown == True)

    def test_g_get_resource(self):
        ex_thrown = False

        try:
            hil.get('all') # this must throw exception as the board is not connected yet!
        except:
            ex_thrown = True

        self.assertTrue(ex_thrown == True)

    def test_h_connect_disconnect(self):
        stack.connect()
        self.assertTrue(stack.is_connected())
        stack.disconnect()
        self.assertFalse(stack.is_connected())
        self.assertFalse(stack.ping())


########################################################################################################################
#
# Tests specific to the HIL python API
#
########################################################################################################################

class TestHilApiBasic(unittest.TestCase):
    def setUp(self):
        global stack, hil
        stack = hilstack.HilStack()
        hil = stack.get_hil_ctrl()
        stack.connect()
        hil.set('ALL', arduinoctrl.ArduinoMega.LOW)

    def tearDown(self):
        global hil, stack
        hil.set('ALL', arduinoctrl.ArduinoMega.LOW)
        stack.disconnect()
        hil = None
        stack = None


class TestHilApi_misc(TestHilApiBasic):
    def test_a_get_boards(self):
        self.assertEqual(hil.get_boards(), ['hil1'])

    def test_b_get_resources(self):
        self.assertEqual(hil.get_resources().sort(), ['USB1', 'USB2', 'USB3', 'SWITCH1', 'SWITCH2', 'SWITCH3',  'POWER1', 'POWER2', 'POWER3'].sort())

    def test_c_hil_fw_ver(self):
        self.assertEqual(stack.get_settings()['arduino']['fw_version'], EXPECTED_FW_VERSION)


class TestHilApi_toggle_resources(TestHilApiBasic):
    def test_a_hilapi_toggle_each_lane_twice(self):
        for i in range(0, 2):
            for resource in ['USB1', 'USB2', 'USB3', 'POWER1', 'POWER2', 'POWER3', 'SWITCH1', 'SWITCH2', 'SWITCH3']:
                hil.set(resource, arduinoctrl.ArduinoMega.HIGH, 'hil1')
                s = hil.get(resource, 'hil1')
                self.assertTrue(s == arduinoctrl.ArduinoMega.HIGH)
                time.sleep(3)
                hil.set(resource, arduinoctrl.ArduinoMega.LOW, 'hil1')
                s = hil.get(resource, 'hil1')
                self.assertTrue(s == arduinoctrl.ArduinoMega.LOW)

    def test_b_hilapi_toggle_all_lanes_all_boards(self):
        hil.set('all', 1)
        all_states = hil.get('all')
        for b in hil.get_boards():
            self.assertDictEqual(all_states[b], all_resources_high_py_format_1_hil)

        time.sleep(3)
        hil.set('all', 0)
        all_states = hil.get('all')
        for b in hil.get_boards():
            self.assertDictEqual(all_states[b], all_resources_low_py_format_1_hil)

    def test_c_hilapi_toggle_all_lanes_each_board(self):
        for b in hil.get_boards():
            hil.set('all', 1, b)
            board_states = hil.get('all', b)
            self.assertDictEqual(board_states, all_resources_high_py_format_1_hil)

            time.sleep(3)
            hil.set('all', 0, b)
            board_states = hil.get('all', b)
            self.assertDictEqual(board_states, all_resources_low_py_format_1_hil)

    def test_d_hilapi_toggle_all_lanes_each_board_valid_call(self):
        ex_thrown = False

        try:
            for b in hil.get_boards():
                hil.set('all', 1) # this must not throw exception as it's valid call
                time.sleep(3)
        except:
            ex_thrown = True

        self.assertTrue(ex_thrown == False)

    def test_e_hilapi_toggle_all_lanes_each_board_invalid_call(self):
        ex_thrown = False

        try:
            for b in hil.get_boards():
                for r in hil.get_resources():
                    hil.set(r, 100) # this must throw exception as it's invalid call
                    time.sleep(3)
        except:
            ex_thrown = True

        self.assertTrue(ex_thrown)

    def test_f_hilapi_invalid_call_wrong_board(self):
        ex_thrown = False

        try:
            hil.set('SWITCH1', 1, 'hil100') # this must throw exception as it's invalid call
        except:
            ex_thrown = True

        self.assertTrue(ex_thrown)

    def test_g_hilapi_invalid_call_wrong_resource(self):
        ex_thrown = False

        try:
            hil.set('SWITCH20', 1, 'hil1') # this must throw exception as it's invalid call
        except:
            ex_thrown = True

        self.assertTrue(ex_thrown)



if __name__ == '__main__':
    unittest.main()