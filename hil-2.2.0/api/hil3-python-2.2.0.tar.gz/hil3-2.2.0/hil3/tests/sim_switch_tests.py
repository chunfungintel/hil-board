############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

__author__ = 'amihaila'

import unittest

import io
import serial
import time
import datetime

from hil3 import hilstack


class BasicSimSwitchTest(unittest.TestCase):
    def setUp(self):
        global stack, sim_sw

        stack = hilstack.HilStack()
        stack.connect()
        sim_sw = stack.get_simsw_ctrl()

    def tearDown(self):
        global stack, sim_sw

        sim_sw = None
        stack.disconnect()
        stack = None


########################################################################################################################
#
# Tests specific to the python API
#
########################################################################################################################
class TestSimSwitchPythonAPI(BasicSimSwitchTest):
    def test_0_light_show_hil_stack(self):
        for board in sorted(sim_sw.get_boards()):
            for sim in sorted(sim_sw.get_sims()):
                stack.set_state(board, sim, 'on')
                self.assertDictEqual(stack.get_state(board), {'sim': sim, 'enabled': True})
                time.sleep(2)

    def test_1_light_show_sim_switches(self):
        for board in sorted(sim_sw.get_boards()):
            for sim in sorted(sim_sw.get_sims()):
                sim_sw.set_state(sim, 'on', board)
                self.assertDictEqual(sim_sw.get_state(board), {'sim': sim, 'enabled': True})
                time.sleep(2)

    def test_2_select_sim_enabled(self):
        for board in sorted(sim_sw.get_boards()):
            sim_sw.enable(board)
            for sim in sorted(sim_sw.get_sims()):
                sim_sw.select_sim(sim, board)
                self.assertDictEqual(sim_sw.get_state(board), {'sim': sim, 'enabled': True})
                time.sleep(2)

    def test_3_select_sim_disabled(self):
        for board in sorted(sim_sw.get_boards()):
            sim_sw.disable(board)
            for sim in sorted(sim_sw.get_sims()):
                sim_sw.select_sim(sim, board)
                self.assertDictEqual(sim_sw.get_state(board), {'sim': sim, 'enabled': False})
                time.sleep(2)

    def test_4_select_sim_enabled_disabled(self):
        for board in sorted(sim_sw.get_boards()):
            for sim in sorted(sim_sw.get_sims()):
                sim_sw.select_sim(sim, board)
                sim_sw.enable(board)
                self.assertDictEqual(sim_sw.get_state(board), {'sim': sim, 'enabled': True})
                time.sleep(1)
                sim_sw.disable(board)
                self.assertDictEqual(sim_sw.get_state(board), {'sim': sim, 'enabled': False})
                time.sleep(2)

if __name__ == '__main__':
    unittest.main()


