############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

__author__ = 'amihaila'

class HilException(Exception):
    pass


class HilWrongFwVersion(HilException):
    pass


class HilNoSession(HilException):
    pass


class HilAlreadyConnected(HilException):
    pass


class HilCommunicationError(HilException):
    pass


class HilCmdTimeoutException(HilCommunicationError):
    pass


class HilCmdWrongException(HilException):
    pass


class ArduinoJSONException(HilException):
    pass


class NoArduinosDetectedException(HilException):
    pass


class MultipleArduinosDetectedException(HilException):
    pass


class UnresponsiveArduinoException(HilCommunicationError):
    pass


class HilBoardInvalidResourceException(HilException):
    pass


class HilBoardInvalidStateException(HilException):
    pass


class SimSwitchWrongCmdException(HilException):
    pass
