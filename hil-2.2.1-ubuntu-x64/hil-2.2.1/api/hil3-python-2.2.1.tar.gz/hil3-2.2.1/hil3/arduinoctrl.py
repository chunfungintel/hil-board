############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

import json
import serial
import time
import re
from serial.tools import list_ports
import logging
from threading import Lock, Timer
import platform

from hilexceptions import *


def get_serial_port():
        """
            Attempts for find the COM port (or device) with an Arduino attached. Expects to find exactly one Arduino.
        """
        arduino_device_pids = [
            '.*PID=2341:0*42.*',  # The device ID of the Arduino Rev 3 USB (with & w/o R3 label on PCB) - www.arduino.cc
            '.*PID=2A03:0*42.*',  # The device ID of the Arduino Rev 3 USB  - www.arduino.org
            '.*PID=2341:0*10.*']  # The device ID of the Arduino Rev 2 USB  - www.arduino.cc
        ports = []

        for port in list_ports.comports():
            for pid_regex in arduino_device_pids:
                if re.match(pid_regex, port[2], re.IGNORECASE):
                    logging.info("Detected Arduino Mega 2560 with VID:PID %s on %s" % (port[2], port[0]))
                    ports.append(port[0])

        if len(ports) == 0:
            raise NoArduinosDetectedException(
                "No Arduino Mega detected. Check that Arduino drivers are installed and the board is plugged in.")
        elif len(ports) > 1:
            raise MultipleArduinosDetectedException("More than 1 Arduino Mega detected: %s" % str(ports))

        try:
            tty_port = ports[0]
            return tty_port
        except IndexError:
            raise NoArduinosDetectedException("Could not find any Arduino Mega attached.")


class ArduinoMega():
    HIL_SIGNATURE = r'^HIL f/w ver ([0-9]+\.[0-9]+\.[0-9]+)\.?$'
    COM_BAUD_RATE = 9600
    HIL_FW_VERSION_REQUIRED = '2.2.1'  # TODO Get this from some package version

    HIL_WATCHDOG_TIMEOUT = 8  # seconds

    HIGH = 1
    LOW = 0

    # To be in sync with resource file of the firmware: HilUartInterface.h
    HIL_CMD_SESSION_OPEN = '$'
    HIL_CMD_SESSION_READ = 'r'
    HIL_CMD_SESSION_CLOSE = '#'
    HIL_CMD_WATCHDOG_SET = 'W'
    HIL_CMD_WATCHDOG_RESET = 'k'
    HIL_CMD_SLEEP = 'D'
    HIL_CMD_WAKE = 'W'
    HIL_CMD_LIST_RES = 'd'
    HIL_CMD_PING = 'p'
    HIL_CMD_WHOAMI = 'w'

    HIL_CMD_RE_OK = "OK"
    HIL_CMD_RE_ERROR = "ERROR"
    HIL_CMD_RE_INVALID_SESSION = "INVALID SESSION"
    HIL_CMD_RE_WRONG_STATE = "WRONG STATE"

    def __init__(self):
        self.__serial = None
        self.__serial_lock = Lock()
        self.__fw_ver = None
        self.__session = None
        self.__rx_buf = None
        self.__wd_timer = None
        self.__wd_timer_lock = Lock()
        self.__sleep = False
        self.__watchdog = False

    def __del__(self):
        """
            Destructor. Close all resources.
        :return:
        """
        if self.is_serial_open():
            self.disconnect()

        self.__serial = None
        self.__serial_lock = None
        self.__wd_timer = None
        self.__wd_timer_lock = None

    def __repr__(self):
        # Add this so that we get a decent representation of the object at the command line
        return '("Arduino Mega 2560 on %s with HIL f/w ver", %s)' % (self.__serial.name, self.__fw_ver)

    def connect(self, session, device=None, reset=True, watchdog=False):
        """
            Connects to Arduino board
        :return:
        """
        logging.info("Connect to Arduino for session %s" % session)

        if not device:
            device = get_serial_port()

        logging.info("Using %s @ %d" % (device, ArduinoMega.COM_BAUD_RATE))

        if self.is_serial_open():
            raise HilAlreadyConnected("The board is already connected on %s port!" % device)

        try:
            self.__serial = serial.Serial(port=device, baudrate=ArduinoMega.COM_BAUD_RATE, timeout=1, dsrdtr=not reset)
            self.__rx_buf = ''
        except serial.SerialException as se:
            self.__serial = None
            raise HilCommunicationError("Error on opening the %s port for session %s! Reason: %s" %
                                        (device, session, se.message))
        except Exception as e:
            self.__serial = None
            raise HilCommunicationError("Error on opening the %s port for session %s! Reason: [%s], [%s]" %
                                        (device, session, type(e).__name__, e.message))

        # wait for the bootloader to finish after the board was reset with DTR=0,
        # and wait for Arduino fw to initialize (e.g. probing)
        time.sleep(1.2)

        if reset:
            logging.info("Reset Arduino")
            self.__fw_ver = self.get_firmware_version()
            if self.__fw_ver != ArduinoMega.HIL_FW_VERSION_REQUIRED:
                raise HilWrongFwVersion("Wrong F/W version found. Expected %s but found %s." %
                                        (ArduinoMega.HIL_FW_VERSION_REQUIRED, self.__fw_ver))
        self._flush_rx_buf()  # consume any other welcome message

        self.session_open(session)

        self.__watchdog = watchdog
        if self.__watchdog:
            self.watchdog_enable()
        self.__sleep = False

    def disconnect(self):
        """
            Disconnects the COM port
        :return:
        """
        logging.info("Disconnect HIL board")

        if self.is_serial_open():
            try:
                self.session_close()
            except HilCommunicationError as e:
                # Should Arduino's WDT be enabled, the Arduino will reset by itself.
                # This allows to close the serial port when it becomes unresponsive.
                logging.warning("Unable to close session: %s", e)

            self._stop_wd_timer()
            self.__sleep = False
            self.__watchdog = False

            try:
                self._flush_rx_buf()
            except Exception as e:
                logging.exception("Unable to successfully flush rx '%s' '%s'", type(e).__name__, e.message)

            self.__serial.close()

            com = self.__serial.name
            self.__serial = None
            logging.info('%s port for Arduino closed', com)
        else:
            logging.info("Arduino was not connected!")

    def exec_command(self, cmd):
        """
            Sends a command to the Arduino board and reads the result back
        :param cmd: the command to be sent via UART
        :raises HilCommunicationError in case Arduino is unresponsive
        :return: the result of that command, or exception is thrown in case of error
        """
        logging.debug("Arduino Tx: %s ", cmd)

        if not self.is_serial_open():
            raise HilNoSession("The board is not connected!")

        if cmd == '':
            return None
        cmd_r = cmd + '\r'
        reply = ''
        err = None

        self.__serial_lock.acquire()
        try:
            self._flush_rx_buf()
            if self.__serial.write(cmd_r) != len(cmd_r):
                raise HilCommunicationError("Error on Arduino Tx for %s" % cmd)
            time.sleep(0.05)  # give little time for Arduino to execute
            ack = self._read_line()
            if ack != cmd:
                raise HilCmdTimeoutException("No correct echo received! Expected (%s) and received (%s)" % (cmd, ack))

            tries_left = 5  # read max 5 lines of text in max 5s from Arduino
            while not err and tries_left:
                line = self._read_line()  # timeout = 1s
                if line:
                    if line in [ArduinoMega.HIL_CMD_RE_OK, ArduinoMega.HIL_CMD_RE_ERROR,
                                ArduinoMega.HIL_CMD_RE_INVALID_SESSION]:
                        err = line
                        break
                    reply += line
                else:
                    break
                tries_left -= 1
        except serial.SerialException as e:
            raise HilCommunicationError("Arduino error: %s" % e)
        except Exception as e:
            msg = "Unexpected error: '%s' '%s'" % (type(e).__name__, e.message)
            logging.exception(msg)
            raise HilCommunicationError(msg)
        finally:
            self.__serial_lock.release()

        logging.debug('Arduino Rx: %s \'%s\'', err, reply)
        if not tries_left:
            logging.debug("Arduino didn't send error code")
            raise HilCmdTimeoutException("Arduino didn't send error code")
        if err == ArduinoMega.HIL_CMD_RE_ERROR:
            logging.debug("Invalid command!")
            raise HilCmdWrongException("Invalid command '%s' to HIL. The rest of the command is ignored!" % cmd)
        if err == ArduinoMega.HIL_CMD_RE_INVALID_SESSION:
            logging.debug("Invalid session!")
            raise HilNoSession("Board probably reset")
        if err == ArduinoMega.HIL_CMD_RE_WRONG_STATE:
            logging.debug("Wrong state")
            raise HilBoardInvalidStateException("Wrong state!")

        return reply

    def query_resources(self, board_type):
        """
            Returns a JSON string with all the available resources for a specific board type
        """
        try:
            res = json.loads(self.exec_command(board_type + ArduinoMega.HIL_CMD_LIST_RES),
                             object_hook=ArduinoMega._json_decode_dict)
        except Exception as ex:
            raise HilException("Error on querying the HIL board for the available resources!\r\nReason: %s" % str(ex))

        return res

    def is_serial_open(self):
        return self.__serial and self.__serial.isOpen()

    def get_settings(self):
        """
            Returns the current settings for the serial port.
        """

        res = {'port': {'port_name': None}, 'fw_version': None, 'connection': 'closed'}

        if self.__serial:
            for s in self.__serial.getSettingsDict():
                res['port'][s] = getattr(self.__serial, s)
            res['port']['port_name'] = self.__serial.name

            res['fw_version'] = self.__fw_ver
            res['connection'] = 'open' if self.is_serial_open() else 'closed'
            res['watchdog'] = self.__watchdog

        return res

    def get_firmware_version(self):
        """
        Reads the firmware version from the welcome message of the Arduino board
        :raises HilCommunicationError in case Arduino is not responsive
        :raises NoArduinosDetectedException in case the welcome message is not as expected
        """
        id_str = self._read_line()

        rex = re.compile(ArduinoMega.HIL_SIGNATURE).match(id_str)
        if not rex:
            raise NoArduinosDetectedException("Arduino board detected on %s but it's not HIL! Found \'%s\'" %
                                              (self.__serial.name, id_str))
        else:
            logging.info('Found Arduino f/w ver %s', rex.group(1))

        return rex.group(1) if rex else None

    def watchdog_enable(self):
        logging.info("Enable watchdog")
        self.exec_command('%c%d' % (ArduinoMega.HIL_CMD_WATCHDOG_SET, ArduinoMega.HIL_WATCHDOG_TIMEOUT))
        self._start_wd_timer()

    def session_open(self, session):
        logging.info("Open session %s" % session)
        self.__session = session
        self.exec_command(ArduinoMega.HIL_CMD_SESSION_OPEN + session)

    def session_close(self):
        """
        Close the active session
        :raises HilCmdTimeoutException in case Arduino is not responsive
        :return:
        """
        logging.info("Close session")
        try:
            self.exec_command(ArduinoMega.HIL_CMD_SESSION_CLOSE)
        finally:
            self.__session = None

    def session_keep_alive(self):
        """
        Timer function that resets the Arduino's wdt
        Should Arduino become unresponsive the wdt won't be reset and the board will reset
        :return:
        """
        try:
            self._do_session_keep_alive()
        except Exception as ex:
            logging.warning("Exception in session_keep_alive %s", ex.message)

    def _do_session_keep_alive(self):
        with self.__wd_timer_lock:
            loc_sleep = self.__sleep

        if not loc_sleep:
            wdt_reset = False
            try:
                self.exec_command(ArduinoMega.HIL_CMD_WATCHDOG_RESET)
                wdt_reset = True
            except HilException as ex:
                # Most likely we can't recover from this so we let Arduino reset
                logging.error("Unable to reset watchdog: %s", ex.message)
                logging.error("HIL board will reset")

            if wdt_reset:
                # Python doesn't have periodic timer so we arm the timer again each time.
                # Kicking the watchdog at a frequency of  (timeout / 2) should be enough.
                # Usually, Arduino will be reset in case the host freezes, so the current campaign is compromised anyway.
                self._start_wd_timer()

    def _start_wd_timer(self):
        """
        Trigger watchdog timer
        :return:
        """
        with self.__wd_timer_lock:
            self.__wd_timer = Timer(ArduinoMega.HIL_WATCHDOG_TIMEOUT / 2., self.session_keep_alive)
            self.__wd_timer.start()

    def _stop_wd_timer(self):
        with self.__wd_timer_lock:
            if self.__wd_timer:
                self.__wd_timer.cancel()  # not guaranteed to cancel the timer

    def sleep(self, seconds):
        """
        When the host wakes, it must call wake().
        :param seconds:
        :return:
        """
        logging.info('Sleep for %ds' % seconds)

        if not self.__watchdog:
            raise UnableToSleep('Watchdog not enabled')

        self.exec_command('%c%d' % (ArduinoMega.HIL_CMD_WATCHDOG_SET, seconds))

        # host should suspend but we disable the timer just in case
        self._stop_wd_timer()
        with self.__wd_timer_lock:
            self.__sleep = True

    def wake(self):
        logging.info('Wake')

        self.ping()
        self.watchdog_enable()
        with self.__wd_timer_lock:
            self.__sleep = False

    def exec_raw_command(self, cmd):
        """
            Executes a sequence of commands on the Arduino and returns any output seen on the serial port. See
            the comments section in arduinoMegaOverSerial.c for available commands and format. The commands inside
            the cmd string should be separated by commas and optionally spaces.
        """
        cmds = cmd.strip(' ').split(',')
        r = ''
        for cmd in cmds:
            if cmd != '':
                r = r + self.exec_command(cmd)
        if r != '':
            return r
        return None

    def ping(self):
        """
        Pings the Arduino board.
        :return: True if the board is online, False otherwise.
        :raises: UnresponsiveArduinoException if the serial communication is open but the Arduino is not responsive.
        """
        logging.info("Ping Arduino")

        if not self.is_serial_open():
            logging.info("Arduino is not connected")
            return False

        logging.debug("serial is open")
        res = False
        try:
            res = self.exec_command(ArduinoMega.HIL_CMD_PING) == "pong"
        except HilNoSession as ex:
            raise ex
        except HilException as ex:
            logging.error("Exception during ping command: %s", ex.message)
            raise UnresponsiveArduinoException("Arduino is not responsive on port %s: %s" %
                                               (self.__serial.name, ex.message))
        logging.info("Arduino is online" if res else "Arduino is offline")
        return res

    def _flush_rx_buf(self):
        self.__rx_buf = ''
        self.__serial.flushInput()

    def _read_line(self):
        """
        Reads one line of text from the COM port. The EOL is identified by \r\n and it must be max 100 chars long.
        This is own implementation instead of Serial.readline() to remove the limitations of pySerial on Linux.
        :raises HilCmdTimeoutException in case EOL is not received
        :return: a string containing the line of text received from Arduino. No \r\n
        """
        line = None
        max_wait_rx = 1.  # timeout of 1 second
        tries_left = 100  # max 100 chars
        wait_rx = max_wait_rx / tries_left
        eol = False

        while tries_left and not eol:
            buf_size = self.__serial.inWaiting()
            if buf_size:
                self.__rx_buf += self.__serial.read(buf_size)
            pos = self.__rx_buf.find('\r\n')
            if pos >= 0:
                line, self.__rx_buf = self.__rx_buf[:pos], self.__rx_buf[pos + 2:]
                eol = True
                break
            time.sleep(wait_rx)
            tries_left -= 1

        if not tries_left:
            raise HilCmdTimeoutException("EOL not received from Arduino. Rx buf='%s'" % line)
            pass

        return line

    @staticmethod
    def convert_val(val):
        """
        Converts from readable states to Arduino logical states
        :param val:
        :return: the value converted to internal representation or raises exception in case of invalid input value
        """
        if val in ['L', 'l', '0', 0, 'Low', 'low', 'LOW', 'off', 'OFF']:
            return ArduinoMega.LOW
        elif val in ['H', 'h', '1', 1, 'High', 'high', 'HIGH', 'on', 'ON']:
            return ArduinoMega.HIGH
        else:
            raise Exception("Invalid value for state ", val)

    @staticmethod
    def _json_decode_dict(data):
        rv = {}
        for key, value in data.iteritems():
            if isinstance(key, unicode):
                key = key.encode('utf-8')
            if isinstance(value, unicode):
                value = value.encode('utf-8')
            elif isinstance(value, dict):
                value = ArduinoMega._json_decode_dict(value)
            rv[key] = value
        return rv
