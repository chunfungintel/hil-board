############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

import json
import re
import logging

from arduinoctrl import ArduinoMega
from hilexceptions import *


class HilBoardCtrl():
    """
    Controller for HIL Boards
    """

    HIL_CONFIG                  = r'^(.*) \[([0-9]) HIL\(s\)\]$'
    HIL_CMD_TYPE                = 'H'
    HIL_CMD_LIST_CONFIG         = 'c'
    HIL_CMD_SET                 = 's'
    HIL_CMD_GET                 = 'g'

    def __init__(self, arduino):
        """
        :param: arduino: The Arduino interface to be used to control the HIL board
        :return:
        """
        self.__arduino          = arduino
        self.__boards           = None
        self.__resources        = None
        self.__config           = None
        self.__count            = None

    def __repr__(self):
        # Add this so that we get a decent representation of the object at the command line
        if self.__arduino.is_serial_open():
            return '("HIL setup in the following configuration: %s")' % self.get_settings()
        else:
            return '("HIL Board is not connected yet and it can\'t be identified yet")'

    def setup(self):
        [self.__config, self.__count] = self.__get_hil_config()  # Arduino checks the F/W version

        # the resources are cached, i.e. not deleted on board disconnect
        res = self.__arduino.query_resources(HilBoardCtrl.HIL_CMD_TYPE)
        self.__boards           = res['HIL']['boards'];
        self.__resources        = {}

        res_types               = res['HIL']['resources'];
        lanes                   = res['HIL']['lanes'];
        for r in res_types.keys():
            for l in lanes.keys():
                res_lane_id = [res_types[r], lanes[l]]
                self.__resources[str(r) + str(l)] = res_lane_id   # convert unicode to ansi

    def get_resources(self):
        """
        Gets the list of all resources available on a HIL board
        :return: The list of all resources available on a HIL board
        """
        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        return self.__resources.keys()

    def get_boards(self):
        """
        Gets the list of all boards connected
        :return: The list of all boards connected
        """
        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        return self.__boards.keys()

    def get_settings(self):
        """
        Returns a dictionary with the current settings of the HIL board(s)
        :return: dictionary with the current settings of the HIL board(s)
        """

        connected = self.__arduino.is_serial_open()

        res = {'config': self.__config if connected else None,
               'count': self.__count if connected else None,
               'resources': self.get_resources() if connected else None}

        return res

    def set(self, resource, state, board=None):
        """
        Sets the state for the specified resource(s) on a specific board or on all boards.

        :param resource: the string identifier of the resource, e.g. 'USB1', 'USB2', etc, or 'ALL' for all resources.
        See get_resources() for identifiers.
        :param state: the state of the resource, e.g. ['L', 'l', '0', 0, 'Low', 'LOW', 'off', 'OFF'] for disabled, and
             ['H', 'h', '1', 1, 'High', 'HIGH', 'on', 'ON'] for enabled, or ArduinoMega.LOW and ArduinoMega.HIGH
        :param board: In case of single HIL configuration, this parameter is optional. For stacked HILs this string
            is the board identifier, e.g. 'hil1', 'hil2'. In case all resources on all boards need to be set then
            this parameter must be 'None'. See self.get_boards() for all board identifiers.
        :return: None. It throws exceptions in case of errors. See the hilexceptions.py module for the list of available exceptions
        """
        logging.info('set(%s, %s, %s)', resource, str(state), board)

        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected.")

        if board:
            board = board.lower()
            if not self.get_boards() or board not in self.get_boards():
                raise HilBoardInvalidResourceException("Unknown or invalid resource specified (%s). Valid values are: "
                                                       "%s" % (board, repr(self.get_boards())))
            _board_id = self.__boards[board]
        else:
            _board_id = None

        resource = resource.upper()
        state = ArduinoMega.convert_val(state)

        if resource == 'ALL':
            self.__send_set_cmd(val=state, res_type=None, lane=None, board_id=_board_id)
            return

        if resource not in self.get_resources():
            raise HilBoardInvalidResourceException("Unknown or invalid resource specified (%s). Valid values are: "
                                                            "%s" % (resource, repr(self.get_resources())))
        res_lane_id = self.__resources[resource]

        return self.__send_set_cmd(res_type = res_lane_id[0], lane = res_lane_id[1], val = state, board_id = _board_id)

    def get(self, resource, board=None):
        """
        Gets the state of the specified resource(s) from a specific board or from all boards.

        :param resource: the string identifier of the resource, e.g. 'USB1', 'USB2', etc, or 'ALL' for all resources
        :param board: In case of single HIL configuration, this parameter is optional. For stacked HILs this string
          is the board identifier, e.g. 'hil1', 'hil2'. In case all resources on all boards need to be set then
          this parameter must be 'None'. See self.get_boards() for all board identifiers.
        :return: the state of the resource: 0 for disabled, and 1 for enabled. When all resources are requested,
            a JSON string is returned with the state of all resources of a specific or all boards.
        """
        logging.info('get(%s, %s)', resource, board)

        # if not self.is_connected():
        if not self.__arduino.is_serial_open():
            raise HilNoSession("The board is not connected!")

        resource = resource.upper()

        if board:
            board = board.lower()
            if not self.get_boards() or board not in self.get_boards():
                raise HilBoardInvalidResourceException("Unknown or invalid board specified (%s). Valid values are: "
                                                       "%s" % (board, repr(self.get_boards())))
            board_id = self.__boards[board]
        else:
            board_id = None

        if resource == 'ALL':
            return self.__send_get_all_cmd(board_id)

        if resource not in self.get_resources():
            raise HilBoardInvalidResourceException("Unknown or invalid resource specified (%s). Valid values are: "
                                                            "%s" % (resource, repr(self.get_resources())))
        res_lane_id = self.__resources[resource]

        state = self.__send_get_cmd(res_lane_id[0], res_lane_id[1], board_id)
        state = ArduinoMega.convert_val(state)

        return state

    def get_all_states(self, board=None):
        """
        Gets the state of all resources from a specific board or from all boards.

        :param board: In case of single HIL configuration, this parameter is optional. For stacked HILs this string
            is the board identifier, e.g. 'hil1', 'hil2'. In case all resources on all boards need to be set then
            this parameter must be 'None'. See self.get_boards() for all board identifiers.
        :return: a JSON string with the state of all resources of a specific or all boards.
            The state of the resource: 0 for disabled, and 1 for enabled.
        """
        return self.get('ALL', board)

    def reset(self):
        """
        Reset the states of the HIL board
        :return:
        """
        self.set('ALL', 'off')

    def __get_hil_config(self):
        """
         find out HIL configuration: single board or stacked boards
        :return:
        """
        config_str = self.__arduino.exec_command(HilBoardCtrl.HIL_CMD_TYPE + HilBoardCtrl.HIL_CMD_LIST_CONFIG)
        rex = re.compile(HilBoardCtrl.HIL_CONFIG).match(config_str)
        if rex:
            config       = rex.group(1)
            count        = int(rex.group(2))

        return [config, count]

    def __send_set_cmd(self, val, res_type=None, lane=None, board_id=None):
        """
            Enables or disables a single resource or en/di all resources on all boards or on a specific board.
        """
        cmd = HilBoardCtrl.HIL_CMD_TYPE + HilBoardCtrl.HIL_CMD_SET

        if board_id is None and res_type is None and lane is None:
            # set all boards and all resources
            cmd += "*=" + str(val)
        elif board_id is not None and res_type is None and lane is None:
            # set all resources of a specific board
            cmd += 'b' + str(board_id) + "*=" + str(val)
        elif board_id is not None and res_type is not None and lane is not None:
            # set a specific resource on a specific board
            cmd += 'b' + str(board_id) + 'r' + str(res_type) + 'l' + str(lane) + '=' + str(val)
        elif board_id is None and res_type is not None and lane is not None:
            # set a specific resource when no shift register is present (no stacked scenario)
            cmd += "b0" + "r" + str(res_type) + "l" + str(lane) + "=" + str(val)
        else:
            raise Exception("Invalid parameters passed to __send_set_cmd(): val=%d, res_type=%d, lane=%d, board_id=%d"
                    % (val, res_type, lane, board_id))

        self.__arduino.exec_command(cmd)

    def __send_get_cmd(self, res_type, lane, board_id = None):
        """
            Gets the status of a single resource identified by its type, lane, and board (optional)
            :return
        """
        if not board_id:
            state = self.__arduino.exec_command(HilBoardCtrl.HIL_CMD_TYPE + HilBoardCtrl.HIL_CMD_GET + 'b0' + 'r' + str(res_type) + 'l' + str(lane))
        else:
            state = self.__arduino.exec_command(HilBoardCtrl.HIL_CMD_TYPE + HilBoardCtrl.HIL_CMD_GET + 'b' + str(board_id) + 'r' + str(res_type) + 'l' + str(lane))

        return state

    def __send_get_all_cmd(self, board_id=None):
        """
            Gets the state of all resources on all boards (if board = None) or of a specific board
        :return:
        """
        cmd = (HilBoardCtrl.HIL_CMD_TYPE + HilBoardCtrl.HIL_CMD_GET + '*') if not board_id else (HilBoardCtrl.HIL_CMD_GET + "b%d*" % board_id)
        try:
            _boards = json.loads(self.__arduino.exec_command(cmd), object_hook=ArduinoMega._json_decode_dict)
            boards = {}
            for b in _boards.keys():
                res = {}
                for res_type in _boards[b].keys():
                    for lane in range(len(_boards[b][res_type])):
                        res[res_type + str(lane + 1)] = _boards[b][res_type][lane]
                boards[b] = res
            return boards if board_id is None \
                else boards[[b for b in self.__boards.keys() if self.__boards[b] == board_id][0]]
        except ValueError:
            raise ArduinoJSONException("Failed to parse JSON from serial port. JSON invalid or no data.")


