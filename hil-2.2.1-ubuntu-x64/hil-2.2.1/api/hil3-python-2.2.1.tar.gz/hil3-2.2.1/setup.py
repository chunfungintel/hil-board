############################################################################
#
# Copyright (c) 2015-2017 Intel Deutschland GmbH, All Rights Reserved.
# Copyright (c) 2014 Intel Mobile Communications GmbH, All Rights Reserved.
#
############################################################################

from distutils.core import setup
setup(
        name='hil3',
        version='2.2.1',
        description='Python module for controlling the H-Cloud (aka HARTS) HARTS IO Lite Stack Boards',
        url='http://harts.intel.com/hil',
        author_email='harts_support@intel.com',
        maintainer='H-Cloud (HARTS & DARS)',
        maintainer_email='harts_support@intel.com',
        platforms=('Any',),
        packages=['hil3', 'hil3.tests'],
        requires=['serial (==3.4)']
)
